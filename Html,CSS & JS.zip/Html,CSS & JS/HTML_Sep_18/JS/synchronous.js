function addNumbers (a, b) {
  let sum = a + b;
  return sum;
}

let result = addNumbers (2, 3);
console.log (result);
