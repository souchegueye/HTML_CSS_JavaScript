function calc (a, b) {
  return a * b;
}

let res = calc (2, 4);
console.log (res);
console.log (calc (6, 3));

function isOddNumber (a, n) {
  a = 3;
  n = 2;
  if (a / n == 0) {
    console.log ("It's a odd number");
  } else console.log ("It's not");
}

console.log (isOddNumber);
