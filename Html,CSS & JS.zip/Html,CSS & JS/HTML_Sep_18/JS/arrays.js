const num = [2, 4, 5, 8, 25, 35];
const colors = ['red', 'blue', 'orange'];
const person = ['Abdou', 25, 'Diop'];

const matrix = [1, 2, 3][(4, 5, 6)][(7, 8, 9)];

const emptyArray = [];

console.log (num[2]);
console.log (colors[0]);
console.log (person[2]);
console.log (matrix[1][2]);
console.log ();
