for (var i = 0; i<=10;i++){

    if (i==7)
    {continue;}
    console.log(i);
}