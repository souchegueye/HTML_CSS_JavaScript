var days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

//to display the elements of the array
for (const d of days) {
  console.log (d);
}
