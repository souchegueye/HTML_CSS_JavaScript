
i=0;
n=10;
do{
    console.log(i*i*i);
    i++;
}while(i<=n);