function checkPalindrome (string) {
  return true;
}
console.log (checkPalindrome ('Anna'));
