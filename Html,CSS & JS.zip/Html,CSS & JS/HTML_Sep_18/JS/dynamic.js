var regno;
regno=1000;
console.log("integer value:"+regno);
regno=459.54;
console.log("float value:"+regno);
regno=true;
console.log("boolean value:"+regno);
regno="twenty";
console.log("string value:"+regno);
